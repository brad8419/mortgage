package com.mercury.common.db;

public interface Dao {
	double findInterest(String state, int type);
	
}
